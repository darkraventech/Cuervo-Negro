# Cuervo Negro 🖤
### Papelería & Servicios Técnicos · Bogotá, Colombia

Sitio web oficial de **Cuervo Negro** — papelería y servicios técnicos.

**Desarrollado por:** Camilo Cruz · Ingeniero de Sistemas  
**Fundación:** 2026  
**Contacto:** +57 313 275 5360

---

## 🚀 Ver en vivo

👉 `https://TU_USUARIO.github.io/cuervo-negro`

---

## 📁 Estructura

```
cuervo-negro/
└── index.html   ← toda la web (CSS + JS + logo incluidos)
└── README.md
```

## 🛠 Cómo actualizar

1. Edita `index.html`
2. Haz commit y push a la rama `main`
3. GitHub Pages publica automáticamente en segundos

---

© 2026 Cuervo Negro · Bogotá, Colombia
